#pragma once
#include "BasicStructs/Color.h"
#include "BasicStructs/Quaternion.h"
#include "BasicStructs/Ray.h"
#include "BasicStructs/RaycastHit.h"
#include "BasicStructs/Rect.h"
#include "BasicStructs/Vector2.h"
#include "BasicStructs/Vector3.h"